# CreditScore-InstaBusiness

Calculating credit score for instabusiness clients based on stated parameters

